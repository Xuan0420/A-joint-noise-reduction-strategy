function [denoised_signal] = waveletDenoise(signal, wavelet, level, threshold)
% 小波软阈值信号降噪函数
% 输入参数：
%   signal - 待降噪的信号
%   wavelet - 选用的小波类型
%   level - 分解的层数
%   threshold - 软阈值设定阈值
% 输出参数：
%   denoised_signal - 降噪后的信号

% 小波分解
[c, l] = wavedec(signal, level, wavelet);

% 计算硬阈值
c_t = wthresh(c, 'h', threshold);

% 重构信号
denoised_signal = waverec(c_t, l, wavelet);

end