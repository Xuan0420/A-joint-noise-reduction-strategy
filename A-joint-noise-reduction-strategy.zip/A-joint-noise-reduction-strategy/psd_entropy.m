function psd = psd_entropy(modes,fs)
    % 计算各模态分量和原始无噪信号的功率谱熵
    for i = 1:size(modes,1)
        % 计算模态分量的功率谱
        [pxx, ~] = pwelch(modes(i, :));
        % 计算模态分量的功率谱熵
        psd(i) = entropy(pxx);
    end
end
