function rs = EMDain(t,fs,y,ys)
%% EMD分解
u = emd(ys);
[m,~] = size(u);

figure
for i=1:m-1
    subplot(m,1,i)
    plot(t,u(i,:),'b-','linewidth',1)
    ylabel(['IMF',num2str(i)]);
    axis tight
end
subplot(m,1,m)
plot(t,u(m,:),'b-','linewidth',1)
ylabel('Res');
axis tight

figure
for i=1:m-1
    subplot(m,1,i)
    
    %% FFT 变换
    [cc,y_f] = hua_fft(u(i,:),fs,1);
    plot(y_f,cc,'b','LineWIdth',1.5);
    ylabel(['FFT IMF',num2str(i)]);
    axis tight
end
subplot(m,1,m)
[cc,y_f] = hua_fft(u(m,:),fs,1);
plot(y_f,cc,'b','LineWIdth',1.5);
axis tight
ylabel('FFT Res');

%% 计算包络熵
[m,n] = size(u);
for i=1:m
    En(i) = BaoluoEntropy(u(i,:));
end
disp(['各个IMF分量的包络熵：' num2str(En)])

%% HHT谱图
[A,f,tt] = hhspectrum(u); %imf各个分量分别进行希尔伯特变换，然后分别做fft，此处的f是归一化的频率

%% A瞬时幅值，f瞬时频率
%% 合成HHT谱图
[E,ttt,Cenf] = toimage(A,f);

%% 绘制HHT谱图
figure
imagesc(t,[0,0.5*fs],E);
set(gca,'YDir','normal')
text(0.05, 0.9, '(a)', 'Units', 'Normalized', 'FontSize', 14,'Color', 'white');
xlabel('Time/s')
ylabel('Frequency/Hz')
title('Hilbert spectrum (EMD)')
ylim([0,1000])
colorbar

%% 计算每个分量和容量的Pearson系数
MI = zeros(1,size(u,1));
for i = 1:size(u,1)
    MI(i) = corr(u(i,:)',y','type','Pearson');
end
disp(['EMD分量和信号的相关系数：',num2str(MI)])

%% 相关系数大于阈值Thr 
Thr = median(MI);
[mm,nn] = find(MI>Thr);

%% 去噪声信号
rs = sum(u(nn,:));

% %% 计算评价指标
% [snr1,rmse1] = EvaMetrix(y,rs);
% disp(['EMD 信噪比SNR：' num2str(snr1)])
% disp(['EMD 均方差RMSE：' num2str(rmse1)])
% CR_emds = corr(y',rs','type','Pearson');
% disp(['EMD 相关系数Corr：' num2str(CR_emds)])

% %% 绘制曲线图
% figure
% plot(t,y,'b-')
% hold on
% plot(t,ys,'r-.')
% hold on
% plot(t,rs,'g-s')
% xlabel('时间')
% ylabel('幅值')
% axis tight
% legend('原始信号','加噪信号','EMD去噪信号')

end