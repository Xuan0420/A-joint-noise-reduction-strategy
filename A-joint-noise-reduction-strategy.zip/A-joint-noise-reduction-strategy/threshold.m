t = 0:0.1:100;
y = 1/10*t-5;
% 阈值获取
thr = thselect(y, 'minimaxi');
%g=std(y)
%thr = sqrt(21*g*100);

% 计算软阈值函数和硬阈值函数
sorh_s = 's'; % 选择软阈值
sorh_h = 'h'; % 选择硬阈值
soft_thr = wthresh(y, sorh_s, thr);
hard_thr = wthresh(y, sorh_h, thr);
imd_thr_1 = improved_threshold2(y, thr, 1, 1);
imd_thr_2 = improved_threshold2(y, thr, 10, 0.1);
imd_thr_3 = improved_threshold2(y, thr, 1, 100);

% 绘制传统软硬阈值函数
figure;

subplot(1, 2, 1);
plot(y, hard_thr,'LineWidth', 1);
title('Hard');
text(0.05, 0.9, '(a)', 'Units', 'Normalized', 'FontSize', 12);
xlabel('w');
ylabel('w1');
grid on; % 添加网格线

subplot(1, 2, 2);
plot(y,soft_thr,'LineWidth', 1);
title('Soft');
text(0.05, 0.9, '(b)', 'Units', 'Normalized', 'FontSize', 12);
xlabel('w');
ylabel('w1');
grid on; % 添加网格线


% % 绘制原始信号
 figure;
 plot(y, y,'w', 'LineWidth', 1.5);
 hold on; % 启用绘图保持状态

% 绘制硬阈值处理后的信号
plot(y, hard_thr, 'color', [014/255 062/255 135/255], 'LineWidth', 1.5);
% 绘制软阈值处理后的信号
plot(y, soft_thr, 'color', [216/255 178/255 058/255], 'LineWidth', 1.5);
% 绘制改进后的阈值处理后的信号
plot(y, imd_thr_3, 'color', [052/255 108/255 172/255], 'LineWidth', 1.5);
% 绘制改进后的阈值处理后的信号
plot(y, imd_thr_2, 'color', [222/255 234/255 234/255], 'LineWidth', 1.5);
% 绘制改进后的阈值处理后的信号
plot(y, imd_thr_1, 'color', [247/255 228/255 116/255] , 'LineWidth', 1.5);


hold off; % 关闭绘图保持状态

legend('', 'Hard','Soft','Improved(α=1,β=100)','Improved(α=10,β=0.1)','Improved(α=1,β=1)');
% title('Improved threshold functions');
xlabel('w');
ylabel('w1');
grid on;