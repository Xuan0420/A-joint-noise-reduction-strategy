function [denoised_signal] = improvedWaveletDenoise(signal, wavelet, level, threshold, alpha, beta)
% 小波阈值信号降噪函数（基于改进的软阈值函数）
% 输入参数：
%   signal - 待降噪的信号
%   wavelet - 选用的小波类型
%   level - 分解的层数
%   lambda, alpha, beta - 阈值函数的三个参数
% 输出参数：
%   denoised_signal - 降噪后的信号

% 小波分解
[c, l] = wavedec(signal, level, wavelet);

% 计算阈值并进行处理
c_t = improved_threshold2(c, threshold,alpha, beta);


% 重构信号
denoised_signal = waverec(c_t, l, wavelet);

end
